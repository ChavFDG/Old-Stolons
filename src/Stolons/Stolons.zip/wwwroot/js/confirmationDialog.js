﻿// Confirmation Dialog

function UpdateBillConfirm(message) {
    if (confirm(message))
        return true;
    else
        return false;
}